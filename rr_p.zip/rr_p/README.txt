

Xamp needed to be installed to run the application.
Turn on the Apache and MySQL in  xamp control panel.
download the zip and place it in the htdocs in xamp folder by extracting.
create a databases test and registration in php my admin.
In test database create a table name `regisstration` with attributes 'name, email, password,usertype'  and in user_db database table name `user_form` with attributes 'name, email, phone, address, type, location.

'http://localhost/rr_p/main.html' to render the website.