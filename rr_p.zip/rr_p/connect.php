<?php
    $name=$_POST['name'];
    $email =$_POST['email'];
    $phone=$_POST['phone'];
    $address=$_POST['address'];
    $type=$_POST['type'];
    $location=$_POST['location'];
   
    $conn = new mysqli('localhost','root','','test');
    if($conn->connect_error){
        die('Connection Failed: '.$conn->connect_error);
    }
    else{
        $stmt=$conn->prepare("insert into regisstration(name,email,phone,address,type,location)
                        values(?,?,?,?,?,?)");
        $stmt->bind_param("sssssi",$name,$email,$phone,$address,$type,$location);
        $stmt->execute();
        echo "successfull";
        header('location: t.html');
        $stmt->close();
        $conn->close();

    }
    class booking
    {
        function booking($name, $email, $phone, $address, $type, $location)
        {
            $db = new DBconnection();
            $dbConn = $db->getConnection();
            $date =  date("Y-m-d");
            $sql = "INSERT INTO regisstration (name,email,phone,address,type,location) VALUES (:name,:email,:phone,:address,:type,:location)";
            $query = $dbConn->prepare($sql);
            $query->bindparam(':name', $name);
            $query->bindparam(':email', $email);
            $query->bindparam(':phone', $phone);
            $query->bindparam(':address', $address);
            $query->bindparam(':type', $type);
            $query->bindparam(':location', $location);
            try {
                if ($query->execute()) :
                    return "success";
                endif;
            } catch (PDOException $e) {
                return $e->getMessage();
            }
        }
    }


?>
